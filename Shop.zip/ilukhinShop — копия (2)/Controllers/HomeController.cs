﻿using ilukhinShop.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace ilukhinShop.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ProductRepository _productRepository;
        private static List<Order> _orders = new List<Order>();
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
            _productRepository = new ProductRepository();
        }

        public IActionResult Index(
            string category = null,
            string brand = null,
            int? minPrice = null,
            int? maxPrice = null,
            string typeDoorOpening = null,
            bool? backlight = null,
            int? minTimerTime = null,
            int? maxTimerTime = null,
            int? minNumberRevolutions = null,
            int? maxNumberRevolutions = null,
            int? minNoiseLevel = null,
            int? maxNoiseLevel = null,
            int? minMaximumLoad = null,
            int? maxMaximumLoad = null,
            int? minVolume = null,
            int? maxVolume = null,
            int? minHeatingTemperature = null,
            int? maxHeatingTemperature = null,
            string bulbMaterial = null)
        {
            var products = _productRepository.GetAll();

            // Фильтрация
            if (!string.IsNullOrEmpty(category))
                products = products.Where(p => p.Category == category).ToList();

            if (!string.IsNullOrEmpty(brand))
                products = products.Where(p => p.Brand == brand).ToList();

            if (minPrice.HasValue)
                products = products.Where(p => p.Price >= minPrice.Value).ToList();

            if (maxPrice.HasValue)
                products = products.Where(p => p.Price <= maxPrice.Value).ToList();

            // для микроволновых печей
            if (!string.IsNullOrEmpty(typeDoorOpening))
                products = products.Where(p => p.TypeDoorOpening == typeDoorOpening).ToList();

            if (backlight.HasValue)
                products = products.Where(p => p.Backlight == backlight).ToList();

            if (minTimerTime.HasValue)
                products = products.Where(p => p.TimerTime >= minTimerTime).ToList();

            if (maxTimerTime.HasValue)
                products = products.Where(p => p.TimerTime <= maxTimerTime).ToList();

            // для стиральных машин
            if (minNumberRevolutions.HasValue)
                products = products.Where(p => p.NumberRevolutions >= minNumberRevolutions).ToList();

            if (maxNumberRevolutions.HasValue)
                products = products.Where(p => p.NumberRevolutions <= maxNumberRevolutions).ToList();

            if (minNoiseLevel.HasValue)
                products = products.Where(p => p.NoiseLevel >= minNoiseLevel).ToList();

            if (maxNoiseLevel.HasValue)
                products = products.Where(p => p.NoiseLevel <= maxNoiseLevel).ToList();

            if (minMaximumLoad.HasValue)
                products = products.Where(p => p.MaximumLoad >= minMaximumLoad).ToList();

            if (maxMaximumLoad.HasValue)
                products = products.Where(p => p.MaximumLoad <= maxMaximumLoad).ToList();

            // Фильтры для чайников
            if (minVolume.HasValue)
                products = products.Where(p => p.Volume >= minVolume).ToList();

            if (maxVolume.HasValue)
                products = products.Where(p => p.Volume <= maxVolume).ToList();

            if (minHeatingTemperature.HasValue)
                products = products.Where(p => p.HeatingTemperature >= minHeatingTemperature).ToList();

            if (maxHeatingTemperature.HasValue)
                products = products.Where(p => p.HeatingTemperature <= maxHeatingTemperature).ToList();

            if (!string.IsNullOrEmpty(bulbMaterial))
                products = products.Where(p => p.BulbMaterial == bulbMaterial).ToList();

            // данные для фильтров в представление
            ViewBag.Categories = _productRepository.GetCategories();
            ViewBag.Brands = _productRepository.GetBrands();
            ViewBag.FilterValues = _productRepository.GetFilterValues();
            ViewBag.PriceRange = _productRepository.GetPriceRange();
            ViewBag.NumericRanges = _productRepository.GetNumericRanges();

            return View(products);
        }

        public IActionResult Details(int id)
        {
            ProductModel item = _productRepository.GetById(id);
            return View(item);
        }

        [HttpPost]
        public IActionResult AddToCart(int productId)
        {
            var product = _productRepository.GetById(productId);
            if (product == null)
                return NotFound();

            var cart = GetCart();
            var cartItem = cart.Items.FirstOrDefault(i => i.Product.Id == productId);

            if (cartItem != null)
            {
                cartItem.Quantity++;
            }
            else
            {
                cart.Items.Add(new CartItem
                {
                    Product = product,
                    Quantity = 1
                });
            }

            SaveCart(cart);
            return RedirectToAction("Cart");
        }

        [HttpPost]
        public IActionResult RemoveFromCart(int productId)
        {
            var cart = GetCart();
            var cartItem = cart.Items.FirstOrDefault(i => i.Product.Id == productId);

            if (cartItem != null)
            {
                if (cartItem.Quantity > 1)
                {
                    cartItem.Quantity--;
                }
                else
                {
                    cart.Items.Remove(cartItem);
                }
                SaveCart(cart);
            }

            return RedirectToAction("Cart");
        }
        [HttpGet]
        public IActionResult Checkout()
        {
            var cart = GetCart();
            if (!cart.Items.Any())
            {
                return RedirectToAction("Cart");
            }
            ViewBag.TotalPrice = cart.TotalPrice;
            return View();
        }

        [HttpPost]
        public IActionResult Checkout(Order order)
        {
            var cart = GetCart();
            if (!cart.Items.Any())
            {
                ModelState.AddModelError("", "Корзина пуста!");
            }

            if (ModelState.IsValid)
            {
                // корзину в заказ
                order.OrderDate = DateTime.Now;
                order.TotalPrice = cart.TotalPrice;
                order.Items = cart.Items.Select(i => new OrderItem
                {
                    ProductId = i.Product.Id,
                    ProductName = $"{i.Product.Brand} {i.Product.Model}",
                    Price = i.Product.Price,
                    Quantity = i.Quantity
                }).ToList();

                SaveCart(new Cart());

                return View("OrderCompleted", order);
            }

            return View(order);
        }

        public IActionResult OrderCompleted(Order order)
        {
            return View(order);
        }
        public IActionResult Cart()
        {
            var cart = GetCart();
            return View(cart);
        }

        private Cart GetCart()
        {
            var cart = HttpContext.Session.Get<Cart>("Cart") ?? new Cart();
            return cart;
        }

        private void SaveCart(Cart cart)
        {
            HttpContext.Session.Set("Cart", cart);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}