﻿namespace ilukhinShop.Models
{
	public class ProductModel
	{
		public int Id { get; set; }
		public string Category { get; set; }
		public string Brand { get; set; }
		public string Model { get; set; }
		public int Price { get; set; }
		public string Description { get; set; }
		public string Image { get; set; }

		public string? TypeDoorOpening { get; set; }
		public int? TimerTime { get; set; }
		public bool? Backlight { get; set; }

		public int? NumberRevolutions { get; set; }
		public int? NoiseLevel { get; set; }
		public int? MaximumLoad { get; set; }

		public int? Volume { get; set; }
		public int? HeatingTemperature { get; set; }
        public string? BulbMaterial{ get; set; }



        public ProductModel(int id, string category, string brand, string model, int price, string image, string? typeDoorOpening, int? timerTime, bool? backlight, int? numberRevolutions, int? noiseLevel, int? maximumLoad, int? volume, int? heatingTemperature, string? bulbMaterial)
        {
			Id = id;
			Category = category;
			Brand = brand;
			Model = model;
			Price = price;			
			Image = image;
			TypeDoorOpening = typeDoorOpening;
			TimerTime = timerTime;
			Backlight = backlight;
			NumberRevolutions = numberRevolutions;
            NoiseLevel = noiseLevel;
			MaximumLoad = maximumLoad;
			Volume = volume;
			HeatingTemperature = heatingTemperature;
			BulbMaterial = bulbMaterial;

			
		}

		
	}
}

