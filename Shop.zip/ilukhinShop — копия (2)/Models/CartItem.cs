﻿namespace ilukhinShop.Models
{
    public class CartItem
    {
        public int ProductId { get; set; }
        public ProductModel Product { get; set; }
        public int Quantity { get; set; }
    }
}