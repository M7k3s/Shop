﻿namespace ilukhinShop.Models
{
    public class ProductRepository
    {
        private List<ProductModel> _products = new()
            {
                new (1, "Стиральная машина", "Бирюса", "WM-ME510/04", 16999,  "1.jpg", null, null, null, 800, 80, 5, 38, null, null),
                new (2, "Стиральная машина", "ATLANT", "СМА 60У1010-00", 29999,  "2.jpg",  null, null, null, 900, 70, 5, 40, null, null),
                new (3, "Стиральная машина", "Hyundai", "WMD8413", 48799, "3.jpg", null, null, null, 800, 75, 6, 44, null, null),
                new (4, "Стиральная машина", "Samsung", "WW60AG4S00CELP", 37999,  "4.jpg",  null, null, null, 1000, 76, 7, 44, null, null),
                new (5, "Стиральная машина", "LG", "F2V3GS6W", 44999, "5.jpg", null, null, null, 1000, 72, 7, 42, null, null),
                new (6, "Микроволновая печь", "Centek", "СТ-1585", 9568,  "6.jpg", "кнопка", 35, true, null, null, null, null, null, null),
                new (7, "Микроволновая печь", "Samsung", "MC28H5013AKBW", 17999,  "7.jpg", "кнопка", 40, true, null, null, null, null, null, null),
                new (8, "Микроволновая печь", "Gorenje", "MO17E1BH", 5999,  "8.jpg", "кнопка", 35, true, null, null, null, null, null, null),
                new (9, "Микроволновая печь", "Bosch", "BEL653MB3", 32890,  "9.jpg", "кнопка", 50, true, null, null, null, null, null, null),
                new (10, "Микроволновая печь", "Starwind", "SMW2420", 4390,  "10.jpg", "кнопка", 30, true, null, null, null, null, null, null),
                new (11, "Чайник", "Dexp", "GP1800", 1580,  "11.jpg", null, null, true, null, null, null, 2, 100, "стекло"),
                new (12, "Чайник", "KitchenAid", "5KEK1722EER", 25990, "12.jpg", null, null, true, null, null, null, 2, 100, "пластик"),
                new (13, "Чайник", "Normann", "AKL-134", 1290,  "13.jpg", null, null, true, null, null, null, 2, 100, "стекло"),
                new (14, "Чайник", "Bork", "K703", 27000,  "14.jpg", null, null, true, null, null, null, 2, 100, "стекло"),
                new (15, "Чайник", "Garlyn", "K-110", 7900,  "15.jpg", null, null, true, null, null, null, 2, 100, "пластик"),


            };
        public List<ProductModel> GetAll()
        {
            return _products;
        }

        public ProductModel GetById(int id)
        {
            return _products.First(item => item.Id == id);
        }
        public List<string> GetCategories()
        {
            return _products.Select(p => p.Category).Distinct().ToList();
        }

        public List<string> GetBrands()
        {
            return _products.Select(p => p.Brand).Distinct().ToList();
        }
        public Dictionary<string, List<string>> GetFilterValues()
        {
            return new Dictionary<string, List<string>>
            {
                ["TypeDoorOpening"] = _products.Where(p => p.TypeDoorOpening != null).Select(p => p.TypeDoorOpening).Distinct().ToList(),
                ["BulbMaterial"] = _products.Where(p => p.BulbMaterial != null).Select(p => p.BulbMaterial).Distinct().ToList()
            };
        }

        public (int min, int max) GetPriceRange()
        {
            return (_products.Min(p => p.Price), _products.Max(p => p.Price));
        }

        public Dictionary<string, (int min, int max)> GetNumericRanges()
        {
            return new Dictionary<string, (int min, int max)>
            {
                ["TimerTime"] = (
                    _products.Where(p => p.TimerTime.HasValue).Min(p => p.TimerTime.Value),
                    _products.Where(p => p.TimerTime.HasValue).Max(p => p.TimerTime.Value)
                ),
                ["NumberRevolutions"] = (
                    _products.Where(p => p.NumberRevolutions.HasValue).Min(p => p.NumberRevolutions.Value),
                    _products.Where(p => p.NumberRevolutions.HasValue).Max(p => p.NumberRevolutions.Value)
                ),
                ["NoiseLevel"] = (
                    _products.Where(p => p.NoiseLevel.HasValue).Min(p => p.NoiseLevel.Value),
                    _products.Where(p => p.NoiseLevel.HasValue).Max(p => p.NoiseLevel.Value)
                ),
                ["MaximumLoad"] = (
                    _products.Where(p => p.MaximumLoad.HasValue).Min(p => p.MaximumLoad.Value),
                    _products.Where(p => p.MaximumLoad.HasValue).Max(p => p.MaximumLoad.Value)
                ),
                ["Volume"] = (
                    _products.Where(p => p.Volume.HasValue).Min(p => p.Volume.Value),
                    _products.Where(p => p.Volume.HasValue).Max(p => p.Volume.Value)
                ),
                ["HeatingTemperature"] = (
                    _products.Where(p => p.HeatingTemperature.HasValue).Min(p => p.HeatingTemperature.Value),
                    _products.Where(p => p.HeatingTemperature.HasValue).Max(p => p.HeatingTemperature.Value)
                )
            };
        }
    }
}
