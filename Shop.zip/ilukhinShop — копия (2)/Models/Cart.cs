﻿using System.Collections.Generic;

namespace ilukhinShop.Models
{
    public class Cart
    {
        public List<CartItem> Items { get; set; } = new List<CartItem>();

        public decimal TotalPrice
        {
            get
            {
                decimal total = 0;
                foreach (var item in Items)
                {
                    total += item.Product.Price * item.Quantity;
                }
                return total;
            }
        }
    }
}